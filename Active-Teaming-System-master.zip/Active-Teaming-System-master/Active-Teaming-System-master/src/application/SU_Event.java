package application;

import java.util.LinkedList;

public class SU_Event {
	private LinkedList<String> fname;
	private LinkedList<String>  lname;
	private LinkedList<String> account;
	private LinkedList<String>  password;
	private LinkedList<String> email;
	private LinkedList<String> interest;
	
	
	public SU_Event() {
		
		fname = new LinkedList<String>();
		lname = new LinkedList<String>();
		account = new LinkedList<String>();
		password = new LinkedList<String>();
		email = new LinkedList<String>();
		interest = new LinkedList<String>();
		
		
		
	}
	public SU_Event(String fname,String lname,String account, String password, String email,String interest) {
		
		this.fname.add(fname);
		this.lname.add(lname);
		this.account.add(account);
		this.password.add(password);
		this.email.add(email);
		this.interest.add(interest);
		
		
	}
	public String generate_acc() {
		
		
		
		
		return " ";
		
		
	}
	public String generate_pass() {
		
		
		
		
		return " ";
		
		
	}
	
	public LinkedList<String> getAccount() {
		return account;
	}
	public void setAccount(LinkedList<String> account) {
		this.account = account;
	}
	public LinkedList<String> getPassword() {
		return password;
	}
	public void setPassword(LinkedList<String> password) {
		this.password = password;
	}
	public LinkedList<String> getEmail() {
		return email;
	}
	public void setEmail(LinkedList<String> email) {
		this.email = email;
	}
	public LinkedList<String> getFname() {
		return fname;
	}
	public void setFname(LinkedList<String> fname) {
		this.fname = fname;
	}
	public LinkedList<String> getLname() {
		return lname;
	}
	public void setLname(LinkedList<String> lname) {
		this.lname = lname;
	}
	public LinkedList<String> getInterest() {
		return interest;
	}
	public void setInterest(LinkedList<String> interest) {
		this.interest = interest;
	}

}
